package account;

    public class Account{
    private String username;        
    private String password;
    private String firstName;
    private String lastName;

    //construtor
    public Account(String username, String password, String firstName, String lastName){
      this.password= password;
      this.firstName= firstName;
      this.lastName= lastName;
    }
     public String getUsernamee(){
         String username = null;
       return username;
   }
     public String getPassword(){
    return password;
}
     public String getfirstName(){
    return firstName;
}
public String getlastName(){
    return lastName;
}
public class PasswordValidator{
    public static boolean validatePassword(String password){
        if (password.length()<8){
            System.out.println("Password must be at least 8 character long");
            return false;
        }
        if (!password.matches("[A-Z]"))
        {
            System.out.println("Password must contain atleast one capital letter");
            return false;
        }
        if (!password.matches("[0-9]"))
        {
           System.out.println("Password must contain atleast one number");
            return false; 
        }
        if (!password.matches("[!@#$%^&(),.?\":{}|<>].*")){
        System.out.println("Password must contain atleast one special character");
            return false; 
        }
        System.out.println("Password is valid");
        return false;
        
    }
    public class Login{
        public static boolean validateUsername(String username){
            if (username.length()<5){
                System.out.println("Username must be at atleast 5 characters long");
                return false;
            }
      public static boolean Register(Account account){
                boolean validUsername= validateUsername(account.getUsername());
                boolean validPassword= PasswordValidator.validatePassword(account.getPassword());
                
            
                
                if (!validUsername){
                    System.out.println("The username is incorrectly formatted");
                }
                if (!validPassword){
                    System.out.println("The password does not meet the complexity requirements");
                }
                if (validUsername && validPassword){
                    System.out.println("The two conditions have been met, and the user has been registered successfully");
                    return true;
                }else{
                    return false;
                    
                }
            }
            public static boolean login(Account account, String username, String password){
                if (account.getUsername().equals(username)&& account.getPassword().equals(password)){
                    System.out.println("'A successful login");
                    return true;
                }else{
                    System.out.println("A failed login");
                    return false;
                }
            }
        }
    }
package account;
import.java.util.Scanner;
public class Account {

    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
